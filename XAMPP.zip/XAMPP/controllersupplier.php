<?php

class SupplierController
{
    public function index()
    {
        $supplier = Supplier::getAll();

        require_once 'view/supplier/index.php';
    }

    public function create()
    {
        require_once 'view/supplier/create.php';
    }

    public function store()
    {
        $id_supplier = $_POST['id_supplier'];
        $nama_supplier = $_POST['nama_supplier'];
        $alamat_supplier = $_POST['alamat_supplier'];
        $no_hp_supplier = $_POST['no_hp_supplier'];

        $supplier = new Supplier($id_supplier, $nama_supplier, $alamat_supplier, $no_hp_supplier);
        $supplier->save();

        header('Location: ?page=supplier');
    }

    public function edit()
    {
        $id_supplier = $_GET['id'];
        $supplier = Supplier::findById($id_supplier);

        require_once 'view/supplier/edit.php';
    }

    public function update()
    {
        $id_supplier = $_POST['id_supplier'];
        $nama_supplier = $_POST['nama_supplier'];
        $alamat_supplier = $_POST['alamat_supplier'];
        $no_hp_supplier = $_POST['no_hp_supplier'];

        $supplier = new Supplier($id_supplier, $nama_supplier, $alamat_supplier, $no_hp_supplier);
        $supplier->update();

        header('Location: ?page=supplier');
    }

