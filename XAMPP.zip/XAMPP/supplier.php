<?php

class Supplier
{
    private $id_supplier;
    private $nama_supplier;
    private $alamat_supplier;
    private $no_hp_supplier;

    public function __construct($id_supplier, $nama_supplier, $alamat_supplier, $no_hp_supplier)
    {
        $this->id_supplier = $id_supplier;
        $this->nama_supplier = $nama_supplier;
        $this->alamat_supplier = $alamat_supplier;
        $this->no_hp_supplier = $no_hp_supplier;
    }

    public function getIdSupplier()
    {
        return $this->id_supplier;
    }

    public function setIdSupplier($id_supplier)
    {
        $this->id_supplier = $id_supplier;
    }

    public function getNamaSupplier()
    {
        return $this->nama_supplier;
    }

    public function setNamaSupplier($nama_supplier)
    {
        $this->nama_supplier = $nama_supplier;
    }

    public function getAlamatSupplier()
    {
        return $this->alamat_supplier;
    }

    public function setAlamatSupplier($alamat_supplier)
    {
        $this->alamat_supplier = $alamat_supplier;
    }

    public function getNoHpSupplier()
    {
        return $this->no_hp_supplier;
    }

    public function setNoHpSupplier($no_hp_supplier)
    {
        $this->no_hp_supplier = $no_hp_supplier;
    }

    public function save()
    {
        $query = "INSERT INTO supplier (id_supplier, nama_supplier, alamat_supplier, no_hp_supplier)
            VALUES (
                '{$this->id_supplier}',
                '{$this->nama_supplier}',
                '{$this->alamat_supplier}',
                '{$this->no_hp_supplier}'
            )";

        mysqli_query($GLOBALS['koneksi'], $query);
    }

    public function update()
    {
        $query = "UPDATE supplier SET
            nama_supplier = '{$this->nama_supplier}',
            alamat_supplier = '{$this->alamat_supplier}',
            no_hp_supplier = '{$this->no_hp_supplier}'
            WHERE id_supplier = '{$this->id_supplier}'";

        mysqli_query($GLOBALS['koneksi'], $query);
    }

    public function delete()
    {
        $query = "DELETE FROM supplier WHERE id_supplier = '{$this->id_supplier}'";

        mysqli_query($GLOBALS['koneksi'], $query);
    }

    public static function getAll()
    {
        $query = "SELECT * FROM supplier";

        $result = mysqli_query($GLOBALS['koneksi'], $query);

        $supplier = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $supplier[] = new Supplier($row['id_supplier'], $row['nama_supplier'], $row['alamat_supplier'], $row['no_hp_supplier']);
        }

        return $supplier;
    }
}





