<?php

class PelangganController
{
    public function index()
    {
        $pelanggan = Pelanggan::getAll();

        require_once 'view/pelanggan/index.php';
    }

    public function create()
    {
        require_once 'view/pelanggan/create.php';
    }

    public function store()
    {
        $id_pelanggan = $_POST['id_pelanggan'];
        $nama_pelanggan = $_POST['nama_pelanggan'];
        $alamat_pelanggan = $_POST['alamat_pelanggan'];
        $no_hp_pelanggan = $_POST['no_hp_pelanggan'];

        $pelanggan = new Pelanggan($id_pelanggan, $nama_pelanggan, $alamat_pelanggan, $no_hp_pelanggan);
        $pelanggan->save();

        header('Location: ?page=pelanggan');
    }

    public function edit()
    {
        $id_pelanggan = $_GET['id'];
        $pelanggan = Pelanggan::findById($id_pelanggan);

        require_once 'view/pelanggan/edit.php';
    }

    public function update()
    {
        $id_pelanggan = $_POST['id_pelanggan'];
        $nama_pelanggan = $_POST['nama_pelanggan'];
        $alamat_pelanggan = $_POST['alamat_pelanggan'];
        $no_hp_pelanggan = $_POST['no_hp_pelanggan'];

        $pelanggan = new Pelanggan($id_pelanggan, $nama_pelanggan, $alamat_pelanggan, $no_hp_pelanggan);
        $pelanggan->update();

        header('Location: ?page=pelanggan');
    }

    public function delete()
    {
        $id_pelanggan = $_GET['id'];
        Pelanggan::deleteById($id_pelanggan);

        header('Location: ?page=pelanggan');
    }
}

