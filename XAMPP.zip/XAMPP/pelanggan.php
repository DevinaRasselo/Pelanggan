<?php

class Pelanggan
{
    private $id_pelanggan;
    private $nama_pelanggan;
    private $alamat_pelanggan;
    private $no_hp_pelanggan;

    public function __construct($id_pelanggan, $nama_pelanggan, $alamat_pelanggan, $no_hp_pelanggan)
    {
        $this->id_pelanggan = $id_pelanggan;
        $this->nama_pelanggan = $nama_pelanggan;
        $this->alamat_pelanggan = $alamat_pelanggan;
        $this->no_hp_pelanggan = $no_hp_pelanggan;
    }

    public function getIdPelanggan()
    {
        return $this->id_pelanggan;
    }

    public function setIdPelanggan($id_pelanggan)
    {
        $this->id_pelanggan = $id_pelanggan;
    }

    public function getNamaPelanggan()
    {
        return $this->nama_pelanggan;
    }

    public function setNamaPelanggan($nama_pelanggan)
    {
        $this->nama_pelanggan = $nama_pelanggan;
    }

    public function getAlamatPelanggan()
    {
        return $this->alamat_pelanggan;
    }

    public function setAlamatPelanggan($alamat_pelanggan)
    {
        $this->alamat_pelanggan = $alamat_pelanggan;
    }

    public function getNoHpPelanggan()
    {
        return $this->no_hp_pelanggan;
    }

    public function setNoHpPelanggan($no_hp_pelanggan)
    {
        $this->no_hp_pelanggan = $no_hp_pelanggan;
    }

    public function save()
    {
        $query = "INSERT INTO pelanggan (id_pelanggan, nama_pelanggan, alamat_pelanggan, no_hp_pelanggan)
            VALUES (
                '{$this->id_pelanggan}',
                '{$this->nama_pelanggan}',
                '{$this->alamat_pelanggan}',
                '{$this->no_hp_pelanggan}'
            )";

        mysqli_query($GLOBALS['koneksi'], $query);
    }

    public function update()
    {
        $query = "UPDATE pelanggan SET
            nama_pelanggan = '{$this->nama_pelanggan}',
            alamat_pelanggan = '{$this->alamat_pelanggan}',
            no_hp_pelanggan = '{$this->no_hp_pelanggan}'
            WHERE id_pelanggan = '{$this->id_pelanggan}'";

        mysqli_query($GLOBALS['koneksi'], $query);
    }

    public function delete()
    {
        $query = "DELETE FROM pelanggan WHERE id_pelanggan = '{$this->id_pelanggan}'";

        mysqli_query($GLOBALS['koneksi'], $query);
    }

    public static function getAll()
    {
        $query = "SELECT * FROM pelanggan";

        $result = mysqli_query($GLOBALS['koneksi'], $query);

        $pelanggan = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $pelanggan[] = new Pelanggan($row['id_pelanggan'], $row['nama_pelanggan'], $row['alamat_pelanggan'], $row['no_hp_pelanggan']);
        }

        return $pelanggan;
    }
}

